<?php $__env->startSection('content'); ?>

    <section class="container sniffer d-flex">

        <div class="p-5 card mx-auto my-auto" style="max-width: 20rem">
            <form action="sniffres" method="POST" class="text-center">
                <?php echo csrf_field(); ?>
                <label for="ico">IČO:&nbsp;</label>
                <input type="text" name="ico">
                <button type="submit" class="mt-3 btn btn-dark">
                    Čmuchej!
                </button>
            </form>
        </div>

    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alpla\Desktop\_work\web\inizio\resources\views/sniff/index.blade.php ENDPATH**/ ?>