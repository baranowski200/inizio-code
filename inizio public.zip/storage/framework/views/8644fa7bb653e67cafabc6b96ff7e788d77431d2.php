<?php $__env->startSection('content'); ?>

    <section class="container p-5 d-flex result">

        <div class="mx-auto my-auto">



        <h1>Výsledek:</h1>

        <br>

        <?php if($passer['pocet_zaznamu'] == 0): ?>
            Pro Váš request <b>(<?php echo e($passer['request']); ?>)</b> nebyl nalezen žádný platný záznam.

                <div class="d-flex pt-5 justify-content-center">
                    <div class="mx-2">
                        <a class="btn btn-dark" href="/sniff">Čmuchat znovu</a>
                    </div>
                </div>
        <?php else: ?>

            <div class="d-flex flex-wrap">
                <div class="col-12 col-lg-6 my-auto">
                    <div>
                        <h2><b><?php echo e($passer['jmeno']); ?></b></h2>
                    </div>
                    <div>
                        <h2><b>IČO: </b><?php echo e($passer['ico']); ?></h2>
                    </div>
                </div>
                <div class="d-flex col-12 col-lg-6">
                    <table class="my-auto">
                        <tr>
                            <td><b>Okres registrace:&nbsp;&nbsp;</b></td>
                            <td class=""><?php echo e($passer['okres']); ?></td>
                        </tr>
                        <tr>
                            <td><b>Adresa:&nbsp;&nbsp;</b></td>
                            <td><?php echo e($passer['adresa']); ?></td>
                        </tr>
                        <tr>
                            <td><b>Vznik registrace:&nbsp;&nbsp;</b></td>
                            <td><?php echo e($passer['vznik']); ?></td>
                        </tr>
                        <tr>
                            <td><b>Platnost registrace:&nbsp;&nbsp;</b></td>
                            <td><?php echo e($passer['platnost']); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <div class="d-flex pt-5 justify-content-center">
                <div class="mx-2">
                    <a class="btn btn-dark" href="/sniff">Čmuchat dále</a>
                </div>
                <div class="mx-2">
                    <a class="btn btn-light" href="javascript:if(window.print)window.print()">Tisk</a>
                </div>
            </div>

        <?php endif; ?>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alpla\Desktop\_work\web\inizio\resources\views/sniff/result.blade.php ENDPATH**/ ?>