<?php $__env->startSection('content'); ?>

    <section class="container p-5 history">

        <h1 class="pt-5 text-center">
            Historie výsledků
        </h1>

        <div class="d-flex justify-content-center">
            <a class="btn btn-dark mx-1" href="/historyaz">A-Z</a>
            <a class="btn btn-dark mx-1" href="/historyza">Z-A</a>
            <a class="btn btn-dark mx-1" href="/historyasc">Vzestupně</a>
            <a class="btn btn-dark mx-1" href="/historydesc">Sestupně</a>
        </div>

        <div class="pt-5">

            <?php $__currentLoopData = $history->sortBy('created_at', '0'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="card m-3 p-3 col-12 col-lg-6 mx-auto">

                    <div class="d-flex flex-column justify-content-between">
                        <div class="m-0">
                            <h2 class="m-0">Podle hledání: <b style="color: #ad0707"><?php echo e($q->request); ?></b></h2>
                        </div>

                        <div class="m-0">
                            <p class="m-0">Datum hledání: <b><?php echo e($q->created_at); ?></b></p>
                        </div>
                    </div>


                    <div class="py-3">
                        <table class="col-12">
                            <tr>
                                <td class="col-6"><b>Údaj</b></td>
                                <td class="col-6" style="text-align: right"><b>Výsledek</b></td>
                            </tr>
                            <tr>
                                <td>IČO</td>
                                <td style="text-align: right"><?php echo e($q->ico); ?></td>
                            </tr>
                            <tr>
                                <td>Jméno</td>
                                <td style="text-align: right"><?php echo e($q->jmeno); ?></td>
                            </tr>
                            <tr>
                                <td>Okres:</td>
                                <td style="text-align: right"><?php echo e($q->okres); ?></td>
                            </tr>
                            <tr>
                                <td>Adresa:</td>
                                <td style="text-align: right"><?php echo e($q->adresa); ?></td>
                            </tr>
                            <tr>
                                <td>Datum vzniku činnosti</td>
                                <td style="text-align: right"><?php echo e($q->vznik); ?></td>
                            </tr>
                            <tr>
                                <td>Datum platnosti činnosti</td>
                                <td style="text-align: right"><?php echo e($q->platnost); ?></td>
                            </tr>
                        </table>
                    </div>

                    <div class="pt-3" style="text-align: right">
                        <a class="btn btn-dark" href="/history/<?php echo e($q->id); ?>">Detail</a>
                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="d-flex justify-content-center pt-5">
            <?php echo $history->links(); ?>

        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alpla\Desktop\_work\web\inizio\resources\views/history/index.blade.php ENDPATH**/ ?>